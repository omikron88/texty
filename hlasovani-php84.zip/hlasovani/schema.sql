CREATE TABLE campaigns (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 mode ENUM('petition','referendum') NOT NULL,
 title VARCHAR(240) NOT NULL,
 body TEXT NOT NULL,
 active BOOLEAN NOT NULL DEFAULT 1,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE votes (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 campaign_id BIGINT UNSIGNED NOT NULL,
 email VARCHAR(254) NOT NULL,
 email_key CHAR(64) NOT NULL,
 name VARCHAR(120) NOT NULL,
 city VARCHAR(120) NOT NULL,
 choice ENUM('yes','no') NOT NULL,
 is_public BOOLEAN NOT NULL DEFAULT 0,
 token_hash CHAR(64) NULL,
 expires_at DATETIME NULL,
 verified_at DATETIME NULL,
 last_sent_at DATETIME NOT NULL,
 UNIQUE KEY one_email (campaign_id,email_key),
 UNIQUE KEY token (token_hash),
 KEY listing (campaign_id,verified_at,id),
 FOREIGN KEY (campaign_id) REFERENCES campaigns(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE rate_limits (
 bucket CHAR(64) PRIMARY KEY,
 hits INT UNSIGNED NOT NULL,
 expires_at DATETIME NOT NULL,
 KEY expiration (expires_at)
) ENGINE=InnoDB;
INSERT INTO campaigns(mode,title,body) VALUES
('petition','Nesouhlasíme s kácením stromů na náměstí','Žádáme zastupitelstvo o zachování vzrostlých stromů na náměstí a o otevřenou diskusi s obyvateli před schválením nové podoby veřejného prostoru.

Stromy jsou součástí našeho města. Poskytují stín, ochlazují okolí a vytvářejí místo pro setkávání. Podpořte výzvu svým podpisem.'),
('referendum','Má město rozšířit pěší zónu v centru?','Souhlasíte s rozšířením pěší zóny v centru města při zachování přístupu pro zásobování a obyvatele?');

-- Tabulky a sloupce editoru (pro novou instalaci).
ALTER TABLE campaigns ADD body_html MEDIUMTEXT NULL;
ALTER TABLE votes ADD campaign_title VARCHAR(240) NULL, ADD campaign_body MEDIUMTEXT NULL, ADD privacy_snapshot MEDIUMTEXT NULL, ADD snapshot_html BOOLEAN NOT NULL DEFAULT 0;
UPDATE votes v JOIN campaigns c ON c.id=v.campaign_id SET v.campaign_title=c.title, v.campaign_body=c.body;
CREATE TABLE site_content (
 id TINYINT UNSIGNED PRIMARY KEY,
 organizer TEXT NOT NULL,
 privacy_html MEDIUMTEXT NOT NULL,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE content_history (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 kind ENUM('campaign','privacy') NOT NULL,
 campaign_id BIGINT UNSIGNED NULL,
 content_json MEDIUMTEXT NOT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
