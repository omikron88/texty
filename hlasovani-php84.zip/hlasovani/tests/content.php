<?php
declare(strict_types=1);
function e(mixed $v): string {return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
require dirname(__DIR__).'/src/content.php';
function check(bool $ok,string $label): void {if(!$ok)throw new Exception($label);echo "OK $label\n";}
$input='<h2>Výzva</h2><p onclick="alert(1)">Žluťoučký <strong>kůň</strong> <em>ano</em></p><ul><li>První</li></ul>';
$safe=cleanHtml($input);
check(str_contains($safe,'Žluťoučký')&&str_contains($safe,'<strong>kůň</strong>')&&str_contains($safe,'<h2>Výzva</h2>')&&!str_contains($safe,'onclick'),'Czech text and supported formatting');
foreach(['<script>alert(1)</script>','<img src=x onerror="alert(1)">','<svg><script>alert(1)</script></svg>','<iframe src="https://example.com"></iframe>','<style>body{display:none}</style>'] as $bad)check(cleanHtml($bad)==='','Remove executable/embedded content');
foreach(['javascript:alert(1)','java&#x73;cript:alert(1)','data:text/html,test','//evil.example','https://examp&#10;le.com','https://example.com&#9;javascript:test'] as $href)check(!str_contains(cleanHtml('<a href="'.$href.'">odkaz</a>'),'href='),'Reject unsafe link');
check(str_contains(cleanHtml('<a href="https://example.com/?a=1&amp;b=2" onclick="x()">Odkaz</a>'),'href="https://example.com/?a=1&amp;b=2"'),'Preserve HTTPS link');
check(str_contains(cleanHtml('<a href="mailto:mail@example.com">Mail</a>'),'mailto:mail@example.com'),'Preserve mail link');
check(cleanHtml($safe)===$safe,'HTML sanitizer is idempotent');
check(campaignHtml(['body'=>'<script>text</script>','body_html'=>null])==='&lt;script&gt;text&lt;/script&gt;','Legacy body remains escaped plain text');
$a=['title'=>'A','body'=>'Text','body_html'=>null];$b=['organizer'=>'Správce','privacy_html'=>'<p>Poučení</p>'];
$first=contentFingerprint($a,$b);$a['title']='B';check($first!==contentFingerprint($a,$b),'Campaign edit invalidates form');$a['title']='A';$b['privacy_html']='<p>Změna</p>';check($first!==contentFingerprint($a,$b),'Privacy edit invalidates form');
try{cleanHtml(str_repeat('x',100001));throw new Exception('Missing size limit');}catch(RuntimeException $e){echo "OK Size limit\n";}
$hash=password_hash('test-secret',PASSWORD_DEFAULT);check(password_verify('test-secret',$hash)&&!password_verify('wrong',$hash),'Admin password hash verification');

check(optionalPages([])===[], 'Optional pages hidden by default');
foreach(['','  ',"\n",'<p><br></p>','<p>&nbsp;</p>','<div>&#8203;</div>','<script>alert(1)</script>','<img src=x onerror=alert(1)>'] as $empty) {
 check(optionalPages(['about_html'=>$empty,'press_html'=>$empty])===[], 'Empty or unsafe-only page stays hidden');
}
$pages=optionalPages(['about_html'=>'<p>Jsme spolek.</p>','press_html'=>'']);
check(array_keys($pages)===['about'], 'About page can be published independently');
$pages=optionalPages(['about_html'=>'','press_html'=>'<p><a href="https://example.com">Článek</a></p>']);
check(array_keys($pages)===['press'], 'Press page can be published independently');
$links=optionalPageLinks(['about_html'=>'<p>O nás</p>','press_html'=>'<p>Články</p>'],'press');
check(substr_count($links,'class="optional-nav"')===2 && substr_count($links,'aria-current="page"')===1, 'Both published pages have navigation links');
check(optionalPageLinks(['about_html'=>'<p>&nbsp;</p>','press_html'=>''])==='', 'Clearing content removes navigation links');
check(!str_contains(optionalPages(['about_html'=>'<p onclick="alert(1)">Jsme spolek.</p>'])['about']['html'],'onclick'), 'Optional page content is sanitized');
