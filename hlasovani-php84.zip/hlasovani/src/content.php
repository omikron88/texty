<?php
declare(strict_types=1);
// Rebuild a small subset of HTML. No scripts, inline styles, event handlers or embeds survive.
function cleanHtml(string $html): string {
 if (strlen($html)>100000) throw new RuntimeException('Text je příliš dlouhý (maximum 100 kB).');
 $doc=new DOMDocument('1.0','UTF-8');
 $previous=libxml_use_internal_errors(true);
 try { $doc->loadHTML('<?xml encoding="UTF-8"><html><body>'.$html.'</body></html>',LIBXML_NONET|LIBXML_NOERROR|LIBXML_NOWARNING); }
 finally { libxml_clear_errors(); libxml_use_internal_errors($previous); }
 $walk=function(DOMNode $node) use (&$walk): string {
  if($node instanceof DOMText) return e($node->nodeValue);
  if(!($node instanceof DOMElement)) return '';
  $tag=strtolower($node->tagName);
  if(in_array($tag,['script','style','iframe','object','embed','svg','math','template','noscript'],true)) return '';
  $inside=''; foreach($node->childNodes as $child) $inside.=$walk($child);
  if($tag==='br') return '<br>';
  if(!in_array($tag,['p','div','h2','h3','strong','b','em','i','u','ul','ol','li','blockquote','a'],true)) return $inside;
  if($tag==='a') {
   $href=trim($node->getAttribute('href'));
   if(!preg_match('~^(https?://|mailto:)~i',$href) || preg_match('/[\x00-\x20\x7f]/',$href)) return $inside;
   return '<a href="'.e($href).'" rel="nofollow noopener noreferrer">'.$inside.'</a>';
  }
  return '<'.$tag.'>'.$inside.'</'.$tag.'>';
 };
 $body=$doc->getElementsByTagName('body')->item(0);$out='';
 if($body) foreach($body->childNodes as $child) $out.=$walk($child);
 return $out;
}
function campaignHtml(array $campaign): string {
 return $campaign['body_html']!==null?cleanHtml($campaign['body_html']):nl2br(e($campaign['body']));
}
function privacyContent(bool $lock=false): array {
 global $config;
 $row=query('SELECT * FROM site_content WHERE id=1'.($lock?' FOR UPDATE':''))->fetch();
 return $row?:['organizer'=>$config['organizer'],'privacy_html'=>nl2br(e($config['privacy']))];
}
function privacyHtml(array $content): string {
 return '<p>'.e($content['organizer']).'</p>'.cleanHtml($content['privacy_html'])
 .'<p>Uchováváme jméno, obec, e-mail, volbu a čas ověření. E-mail ani individuální volbu nezveřejňujeme. Ověření e-mailu nepotvrzuje totožnost ani volební oprávnění. Toto je občanské hlasování, nikoli úřední referendum nebo automaticky právně platná petice.</p>';
}
function contentFingerprint(array $campaign,array $privacy): string {
 return hash('sha256',json_encode([$campaign['title'],$campaign['body'],$campaign['body_html'],$privacy['organizer'],$privacy['privacy_html']],JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR));
}
function history(string $kind,?int $id,array $content): void {
 query('INSERT INTO content_history(kind,campaign_id,content_json) VALUES (?,?,?)',[$kind,$id,json_encode($content,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR)]);
}
