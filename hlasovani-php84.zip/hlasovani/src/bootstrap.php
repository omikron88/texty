<?php
declare(strict_types=1);
require dirname(__DIR__).'/vendor/autoload.php';
$config = require dirname(__DIR__).'/config.php';
if (strlen($config['secret']) < 32 || str_contains($config['secret'],'REPLACE')) { http_response_code(503); exit('Nejprve nastavte bezpečný secret.'); }
date_default_timezone_set('UTC');
ini_set('session.use_strict_mode','1');
session_set_cookie_params(['secure'=>true,'httponly'=>true,'samesite'=>'Lax']);
session_start();
header("Content-Security-Policy: default-src 'self'; style-src 'self'; script-src 'self'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'");
header('Referrer-Policy: no-referrer');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');
$db = new PDO($config['dsn'],$config['db_user'],$config['db_password'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_EMULATE_PREPARES=>false,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
$db->exec("SET time_zone = '+00:00'");
$_SESSION['csrf'] ??= bin2hex(random_bytes(32));
function e(mixed $v): string { return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8'); }
function query(string $sql,array $args=[]): PDOStatement { global $db; $q=$db->prepare($sql); $q->execute($args); return $q; }
function csrf(): void { if(!hash_equals($_SESSION['csrf'],(string)($_POST['csrf']??''))) { http_response_code(403); exit('Platnost formuláře vypršela. Obnovte stránku.'); } }
function limitRequests(): void {
 global $config,$db;
 $bucket=hash_hmac('sha256',($_SERVER['REMOTE_ADDR']??'unknown').'|'.gmdate('Y-m-d-H'),$config['secret']);
 query('INSERT INTO rate_limits(bucket,hits,expires_at) VALUES (?,1,DATE_ADD(UTC_TIMESTAMP(), INTERVAL 2 HOUR)) ON DUPLICATE KEY UPDATE hits=hits+1',[$bucket]);
 if((int)query('SELECT hits FROM rate_limits WHERE bucket=?',[$bucket])->fetchColumn()>10) throw new RuntimeException('Příliš mnoho pokusů. Zkuste to prosím později.');
}
function sendVerification(string $email,string $token,string $title): void {
 global $config;
 $s=$config['smtp']; $m=new PHPMailer\PHPMailer\PHPMailer(true);
 $m->isSMTP(); $m->Host=$s['host']; $m->Port=$s['port']; $m->SMTPAuth=true;
 $m->Username=$s['username']; $m->Password=$s['password']; $m->SMTPSecure=$s['encryption'];
 $m->Timeout=15; $m->CharSet='UTF-8'; $m->setFrom($s['from'],$s['name']); $m->addAddress($email);
 $m->Subject='Potvrďte svůj hlas – Společný hlas';
 $m->Body="Potvrďte hlasování: ".$title."\n\n".$config['base_url'].'/verify.php?token='.rawurlencode($token)."\n\nOdkaz platí 24 hodin. Na otevřené stránce hlas potvrďte tlačítkem. Pokud jste nehlasovali, zprávu ignorujte.";
 $m->send();
}
