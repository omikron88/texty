# Společný hlas — PHP 8.4 / MySQL / SMTP

## Instalace
1. Na serveru spusťte `composer install --no-dev --prefer-dist` (vyžaduje Composer, PHP 8.4, PDO MySQL a mbstring).
2. Importujte `schema.sql` do prázdné MySQL databáze. Ukázková hlasování nahraďte vlastním textem.
3. Zkopírujte `config.example.php` do `config.php`. Doplňte databázi, SMTP a HTTPS adresu bez koncového lomítka. Secret vygenerujte `php -r 'echo bin2hex(random_bytes(32)), PHP_EOL;'`. Po spuštění jej neměňte bez migrace e-mailových klíčů.
4. Nastavte document root webu **výhradně na adresář public/**. Konfigurace, vendor, SQL a zdrojové soubory nesmějí být dostupné přes web. HTTPS je povinné kvůli bezpečným cookies. Vypněte display_errors a zapněte neveřejný error_log.
5. Doplňte skutečného správce osobních údajů, právní základ, dobu uchování a kontakt v konfiguraci. Nastavte SPF, DKIM a DMARC na odesílací doméně.

## Hlasování
- Petice: `/?id=1`. Referendum: `/?id=2`. Lze vytvořit další záznamy v campaigns; administrace upravuje obsah existujících hlasování, veřejné zakládání hlasování není součástí aplikace.
- `mode` je petition nebo referendum. `active=0` uzavře odesílání i potvrzování. Pro novou otázku založte nové hlasování; režim probíhajícího hlasování neměňte.
- Hlas se započítá až po otevření jednorázového odkazu a potvrzení tlačítkem (e-mailové skenery samotným GET hlas nepotvrdí).
- Odkaz má 256bitový náhodný token, v databázi je pouze SHA-256 otisk; expirace 24 hodin. Jedna normalizovaná e-mailová adresa může hlasovat jednou v jednom hlasování; vynucuje unikátní databázový index. Plus aliasy různých poskytovatelů se neslučují.
- Neověřené podání lze aktualizovat a poslat znovu po pěti minutách. Po ověření je hlas neměnný. Odpověď formuláře neprozrazuje, zda adresa už hlasovala.
- Limit 10 podání za hodinu na IP adresu; IP se ukládá jen jako hodinový HMAC. REMOTE_ADDR se nepřepisuje nedůvěryhodnými proxy hlavičkami. Při použití proxy nakonfigurujte skutečnou IP na webserveru. Sdílené IP mohou narazit na limit; distribuované útoky vyžadují doplnění omezení na proxy/WAF.
- Veřejný výpis stránkuje po deseti ověřených hlasech, nezveřejňuje e-mail ani jednotlivou volbu. Jméno a obec pouze po zaškrtnutí samostatné volby, která je vždy výchozí vypnutá. Skryté řádky mají požadovaný text.

## Údržba
Spouštějte pravidelně přes databázový plánovač nebo cron:

```sql
DELETE FROM rate_limits WHERE expires_at < UTC_TIMESTAMP();
DELETE FROM votes WHERE verified_at IS NULL AND last_sent_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL 7 DAY);
```
Nastavte zálohování a výmaz ověřených údajů podle zveřejněné doby uchování. Žádosti o přístup či výmaz vyřizuje provozovatel po ověření žadatele. Tajný e-mailový klíč i zálohy chraňte jako osobní údaje. Referendum je občanský průzkum, nikoli úřední referendum. E-mail nepotvrzuje totožnost ani jednu fyzickou osobu; pro vyšší důvěryhodnost je potřeba silnější identita.

## Ověření před ostrým spuštěním
V prostředí s PHP/MySQL/SMTP ověřte oba režimy, doručení a expiraci e-mailu, opakované potvrzení, souběžné podání stejného e-mailu, uzavřenou kampaň, skryté/veřejné řádky a stránkování s více než deseti potvrzenými hlasy. Bez vyplněné infrastruktury není odesílání e-mailů ověřené.


## Aktualizace na verzi s administrací
1. Zálohujte soubory a databázi. Zapněte krátkou údržbu webu.
2. Na existující databázi spusťte **pouze `migrations/002-editor.sql`**, jednou. Neimportujte znovu schema.sql! Pro novou instalaci stačí schema.sql a migraci již nespouštějte.
3. Nahrajte nové soubory `src/`, `public/` a composer.json. Vlastní config.php a vendor nepřepisujte. Ověřte PHP rozšíření DOM a spusťte `composer install --no-dev --prefer-dist`.
4. Vytvořte hash hesla lokálně nebo přes SSH; příkaz si heslo vyžádá a nepředává jej v argumentech:

```bash
php -r '$p=readline("Nové heslo správce: "); echo password_hash($p, PASSWORD_DEFAULT), PHP_EOL;'
```

Pozor: readline znaky při psaní zobrazuje, spusťte jej v soukromém terminálu. Do svého config.php přidejte položku `'admin_password_hash' => 'VYGENEROVANY_HASH',`. Použijte dlouhé unikátní heslo; prázdný hash administraci vypíná.
5. Otevřete `/admin.php` přes HTTPS a přihlaste se. Poučení se při prvním přihlášení zkopíruje z dosavadní konfigurace do databáze; poté se upravuje v administraci, již ne v config.php. Klíče organizer a privacy v konfiguraci zatím ponechte jako záložní hodnoty.
6. Otestujte uložení a zobrazení obou textů, formátování, odkaz Osobní údaje v horní liště na mobilu a nové ověření hlasu.

Editor podporuje nadpisy, odstavce, tučné a kurzívní písmo, seznamy a odkazy. Vkládání ze schránky přebírá pouze text; formátování doplňte tlačítky editoru. HTML při ukládání i zobrazení filtrujeme na povolené značky. Bez JavaScriptu lze editovat HTML v textovém poli. Přihlášení vyprší po 30 minutách nečinnosti, limit je 10 pokusů za hodinu na IP. Změna hashe hesla zneplatní existující přihlášení.

Každá úprava ukládá předchozí i nové znění do content_history; návrat lze provést zkopírováním znění do editoru (automatické obnovení není součástí). Nové hlasy uchovávají přesné znění výzvy a poučení, které se zobrazí při potvrzování. U starších hlasů migrace zachytí aktuální znění výzvy; dřívější historické znění ani tehdejší poučení nelze zpětně rekonstruovat. Při změně obsahu během vyplňování formuláře bude uživatel požádán o nové přečtení a odeslání. Pro zásadní změnu otázky založte nové hlasování.

## Kontroly editoru
S PHP 8.4 a rozšířením DOM spusťte `php tests/content.php`. Kontroluje filtr HTML, zachování češtiny, bezpečné odkazy a rozpoznání změny obsahu. Změny databáze a skutečný průchod přes SMTP ověřte na testovací instalaci před nasazením.
