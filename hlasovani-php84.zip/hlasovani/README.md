# Společný hlas — PHP 8.4 / MySQL / SMTP

## Instalace
1. Na serveru spusťte `composer install --no-dev --prefer-dist` (vyžaduje Composer, PHP 8.4, PDO MySQL a mbstring).
2. Importujte `schema.sql` do prázdné MySQL databáze. Ukázková hlasování nahraďte vlastním textem.
3. Zkopírujte `config.example.php` do `config.php`. Doplňte databázi, SMTP a HTTPS adresu bez koncového lomítka. Secret vygenerujte `php -r 'echo bin2hex(random_bytes(32)), PHP_EOL;'`. Po spuštění jej neměňte bez migrace e-mailových klíčů.
4. Nastavte document root webu **výhradně na adresář public/**. Konfigurace, vendor, SQL a zdrojové soubory nesmějí být dostupné přes web. HTTPS je povinné kvůli bezpečným cookies. Vypněte display_errors a zapněte neveřejný error_log.
5. Doplňte skutečného správce osobních údajů, právní základ, dobu uchování a kontakt v konfiguraci. Nastavte SPF, DKIM a DMARC na odesílací doméně.

## Hlasování
- Petice: `/?id=1`. Referendum: `/?id=2`. Lze vytvořit další záznamy v campaigns; žádná administrace ani veřejné zakládání hlasování nejsou součástí aplikace.
- `mode` je petition nebo referendum. `active=0` uzavře odesílání i potvrzování. Text a režim hlasování po prvním hlasu neměňte; pro novou otázku založte nové hlasování.
- Hlas se započítá až po otevření jednorázového odkazu a potvrzení tlačítkem (e-mailové skenery samotným GET hlas nepotvrdí).
- Odkaz má 256bitový náhodný token, v databázi je pouze SHA-256 otisk; expirace 24 hodin. Jedna normalizovaná e-mailová adresa může hlasovat jednou v jednom hlasování; vynucuje unikátní databázový index. Plus aliasy různých poskytovatelů se neslučují.
- Neověřené podání lze aktualizovat a poslat znovu po pěti minutách. Po ověření je hlas neměnný. Odpověď formuláře neprozrazuje, zda adresa už hlasovala.
- Limit 10 podání za hodinu na IP adresu; IP se ukládá jen jako hodinový HMAC. REMOTE_ADDR se nepřepisuje nedůvěryhodnými proxy hlavičkami. Při použití proxy nakonfigurujte skutečnou IP na webserveru. Sdílené IP mohou narazit na limit; distribuované útoky vyžadují doplnění omezení na proxy/WAF.
- Veřejný výpis stránkuje po deseti ověřených hlasech, nezveřejňuje e-mail ani jednotlivou volbu. Jméno a obec pouze po zaškrtnutí samostatné volby, která je vždy výchozí vypnutá. Skryté řádky mají požadovaný text.

## Údržba
Spouštějte pravidelně přes databázový plánovač nebo cron:

```sql
DELETE FROM rate_limits WHERE expires_at < UTC_TIMESTAMP();
DELETE FROM votes WHERE verified_at IS NULL AND last_sent_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL 7 DAY);
```
Nastavte zálohování a výmaz ověřených údajů podle zveřejněné doby uchování. Žádosti o přístup či výmaz vyřizuje provozovatel po ověření žadatele. Tajný e-mailový klíč i zálohy chraňte jako osobní údaje. Referendum je občanský průzkum, nikoli úřední referendum. E-mail nepotvrzuje totožnost ani jednu fyzickou osobu; pro vyšší důvěryhodnost je potřeba silnější identita.

## Ověření před ostrým spuštěním
V prostředí s PHP/MySQL/SMTP ověřte oba režimy, doručení a expiraci e-mailu, opakované potvrzení, souběžné podání stejného e-mailu, uzavřenou kampaň, skryté/veřejné řádky a stránkování s více než deseti potvrzenými hlasy. Bez vyplněné infrastruktury není odesílání e-mailů ověřené.
