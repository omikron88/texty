-- Spusťte jednou na existující instalaci s migrací 002-editor.sql.
ALTER TABLE site_content ADD about_html MEDIUMTEXT NULL, ADD press_html MEDIUMTEXT NULL;
ALTER TABLE content_history MODIFY kind ENUM('campaign','privacy','page') NOT NULL;
