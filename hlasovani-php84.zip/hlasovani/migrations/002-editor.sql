-- Spustit jednou na existující databázi. Předem vytvořte zálohu.
ALTER TABLE campaigns ADD body_html MEDIUMTEXT NULL;
ALTER TABLE votes ADD campaign_title VARCHAR(240) NULL, ADD campaign_body MEDIUMTEXT NULL, ADD privacy_snapshot MEDIUMTEXT NULL, ADD snapshot_html BOOLEAN NOT NULL DEFAULT 0;
UPDATE votes v JOIN campaigns c ON c.id=v.campaign_id SET v.campaign_title=c.title, v.campaign_body=c.body;
CREATE TABLE site_content (
 id TINYINT UNSIGNED PRIMARY KEY,
 organizer TEXT NOT NULL,
 privacy_html MEDIUMTEXT NOT NULL,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE content_history (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 kind ENUM('campaign','privacy') NOT NULL,
 campaign_id BIGINT UNSIGNED NULL,
 content_json MEDIUMTEXT NOT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
