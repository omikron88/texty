<?php
return [
 'dsn'=>'mysql:host=localhost;dbname=hlasovani;charset=utf8mb4',
 'db_user'=>'hlasovani', 'db_password'=>'CHANGE_ME',
 'base_url'=>'https://hlasovani.example.cz',
 'secret'=>'REPLACE_WITH_64_RANDOM_HEX_CHARACTERS',
 'smtp'=>['host'=>'smtp.example.cz','port'=>587,'username'=>'','password'=>'','encryption'=>'tls','from'=>'hlasovani@example.cz','name'=>'Společný hlas'],
 'organizer'=>'Doplňte jméno a kontakt správce údajů',
 'privacy'=>'Údaje používáme k ověření hlasu. Doplňte dobu uchování, právní základ a kontakt pro uplatnění práv před spuštěním.'
];
