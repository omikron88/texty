<?php
require dirname(__DIR__).'/src/bootstrap.php';
$id=max(1,(int)($_GET['id']??1));
$c=query('SELECT * FROM campaigns WHERE id=?',[$id])->fetch();
if(!$c){http_response_code(404);exit('Hlasování neexistuje.');}
$error=''; $sent=false;
if($_SERVER['REQUEST_METHOD']==='POST') {
 csrf();
 try {
  if(!$c['active']) throw new RuntimeException('Hlasování je uzavřeno.');
  limitRequests();
  $email=strtolower(trim((string)($_POST['email']??'')));
  $name=trim((string)($_POST['name']??'')); $city=trim((string)($_POST['city']??''));
  $choice=$c['mode']==='petition'?'yes':($_POST['choice']??'');
  if(!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($email)>254||mb_strlen($name)<2||mb_strlen($name)>120||mb_strlen($city)<2||mb_strlen($city)>120||!in_array($choice,['yes','no'],true)||!isset($_POST['consent'])||!empty($_POST['website'])) throw new RuntimeException('Zkontrolujte jméno, obec, e-mail, volbu a potvrzení seznámení s podmínkami.');
  $key=hash_hmac('sha256',$email,$config['secret']);
  $token=bin2hex(random_bytes(32));
  $db->beginTransaction();
  query('INSERT IGNORE INTO votes(campaign_id,email,email_key,name,city,choice,is_public,last_sent_at) VALUES (?,?,?,?,?,?,?,DATE_SUB(UTC_TIMESTAMP(),INTERVAL 1 DAY))',[$id,$email,$key,$name,$city,$choice,isset($_POST['public'])?1:0]);
  $v=query('SELECT * FROM votes WHERE campaign_id=? AND email_key=? FOR UPDATE',[$id,$key])->fetch();
  if(!$v['verified_at'] && strtotime($v['last_sent_at'])<time()-300){
   query('UPDATE votes SET name=?,city=?,choice=?,is_public=?,token_hash=?,expires_at=DATE_ADD(UTC_TIMESTAMP(),INTERVAL 24 HOUR),last_sent_at=UTC_TIMESTAMP() WHERE id=?',[$name,$city,$choice,isset($_POST['public'])?1:0,hash('sha256',$token),$v['id']]);
   sendVerification($email,$token,$c['title']);
  }
  $db->commit(); $sent=true;
 } catch(Throwable $ex) {
  if($db->inTransaction())$db->rollBack();
  $error=$ex instanceof RuntimeException && !($ex instanceof PDOException) && !($ex instanceof PHPMailer\PHPMailer\Exception)?$ex->getMessage():'Hlas se nepodařilo odeslat. Zkuste to později.';
  if($error==='Hlas se nepodařilo odeslat. Zkuste to později.') error_log('Vote submission failed: '.get_class($ex));
 }
}
$stats=query("SELECT COUNT(*) total,COALESCE(SUM(choice='yes'),0) yes_count FROM votes WHERE campaign_id=? AND verified_at IS NOT NULL",[$id])->fetch();
$total=(int)$stats['total']; $pages=max(1,(int)ceil($total/10)); $page=min($pages,max(1,(int)($_GET['page']??1))); $offset=($page-1)*10;
$rows=query("SELECT id,is_public,CASE WHEN is_public=1 THEN name ELSE NULL END name,CASE WHEN is_public=1 THEN city ELSE NULL END city,verified_at FROM votes WHERE campaign_id=? AND verified_at IS NOT NULL ORDER BY verified_at DESC,id DESC LIMIT 10 OFFSET $offset",[$id])->fetchAll();
$all=query('SELECT id,mode,title FROM campaigns ORDER BY id')->fetchAll();
?><!doctype html><html lang="cs"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=e($c['title'])?> · Společný hlas</title><link rel="stylesheet" href="style.css"></head><body>
<header><a class="brand" href="./"><span class="logo">s<span>h</span></span> společný hlas<span class="brand-dot">.</span></a><nav><a href="#vyzva">O výzvě</a><a href="#signatari">Ověřené hlasy</a><a class="nav-cta" href="#hlasovat">Zapojit se ↗</a></nav></header>
<main><div class="breadcrumb">OBČANSKÁ INICIATIVA <span>/</span> VÁŠ HLAS MÁ VÁHU</div><div class="layout"><article id="vyzva"><div class="eyebrow"><span class="live"></span> <?= $c['active']?'PROBÍHAJÍCÍ':'UZAVŘENÉ' ?> <?= $c['mode']==='petition'?'PETICE':'REFERENDUM' ?></div><h1><?=e($c['title'])?><span class="accent">.</span></h1><p class="intro">Na změně se můžeme podílet společně. Přidejte svůj ověřený hlas a dejte najevo svůj názor.</p><div class="statement"><span class="quote">“</span><div><?=nl2br(e($c['body']))?></div></div><div class="trust"><span>✓ Ověřeno e-mailem</span><span>◉ Soukromí pod kontrolou</span></div><div class="about"><span>01 / JAK TO FUNGUJE</span><h2>Malý krok. Společný dopad.</h2><p>Vyplňte formulář a potvrďte svůj hlas odkazem v e-mailu. Teprve potom jej započítáme. Vaše jméno a obec zůstanou skryté, pokud sami nezvolíte jejich zveřejnění.</p></div></article>
<aside id="hlasovat"><div class="card-top"><span>KAŽDÝ HLAS SE POČÍTÁ</span><span>↗</span></div><div class="count"><?=number_format($total,0,',',' ')?><span>ověřených <?= $c['mode']==='petition'?'podpisů':'hlasů' ?></span></div><?php if($c['mode']==='referendum'): ?><div class="results"><span>ANO <?= (int)$stats['yes_count'] ?></span><span>NE <?= $total-(int)$stats['yes_count'] ?></span></div><?php endif ?><hr><h2><?= $c['mode']==='petition'?'Přidejte svůj podpis':'Vyjádřete svůj názor' ?></h2><p class="muted">Zabere to jen chvilku. Změnit to může hodně.</p>
<?php if($sent): ?><div class="notice" role="status"><strong>Zkontrolujte svou e-mailovou schránku.</strong><p>Pokud lze hlas ověřit, obdržíte potvrzovací odkaz. Zkontrolujte i spam. Již ověřený hlas se znovu nepřičítá. Opakované zaslání je možné po 5 minutách.</p></div><?php elseif(!$c['active']): ?><p>Hlasování je uzavřeno.</p><?php else: ?>
<?php if($error): ?><p class="error" role="alert"><?=e($error)?></p><?php endif ?>
<form method="post" action="?id=<?=$id?>#hlasovat"><input type="hidden" name="csrf" value="<?=e($_SESSION['csrf'])?>">
<?php if($c['mode']==='referendum'): ?><fieldset><legend>Vaše volba</legend><label><input type="radio" name="choice" value="yes" required> ANO</label><label><input type="radio" name="choice" value="no" required> NE</label></fieldset><?php endif ?>
<label class="field">Jméno a příjmení<input name="name" autocomplete="name" required minlength="2" maxlength="120" placeholder="Jan Novák" value="<?=e($_POST['name']??'')?>"></label><label class="field">Obec / město<input name="city" autocomplete="address-level2" required minlength="2" maxlength="120" placeholder="Např. Praha" value="<?=e($_POST['city']??'')?>"></label><label class="field">E-mailová adresa<input type="email" name="email" autocomplete="email" required maxlength="254" placeholder="vas@email.cz" value="<?=e($_POST['email']??'')?>"></label><small>Na tuto adresu pošleme odkaz pro ověření hlasu. E-mail nikdy nezveřejníme.</small>
<div class="trap" aria-hidden="true"><label>Web<input name="website" tabindex="-1" autocomplete="off"></label></div>
<label class="check"><input type="checkbox" name="public"><span>Chci zveřejnit své jméno a obec ve výpisu signatářů.<small>Volitelné. Ve výchozím nastavení jste skryti.</small></span></label><label class="check"><input type="checkbox" name="consent" required><span>Seznámil/a jsem se se <a href="#soukromi">zpracováním osobních údajů</a>.</span></label><button type="submit"><?= $c['mode']==='petition'?'Podepsat petici':'Odeslat hlas' ?><span>↗</span></button><div class="secure">⌑ Hlas se započítá po ověření e-mailu</div></form><?php endif ?></aside></div>
<section id="signatari"><div class="section-top"><div class="eyebrow">SPOJUJE NÁS SPOLEČNÝ NÁZOR</div><span class="pill"><?=$total?> ověřených hlasů</span></div><h2><?= $c['mode']==='petition'?'Ti, kteří se už přidali':'Ověření účastníci hlasování' ?></h2><p class="muted">Za každým hlasem je rozhodnutí. Zveřejnění údajů je vždy dobrovolné.</p><div class="table-wrap"><table><thead><tr><th>Jméno a příjmení</th><th>Obec</th><th>Datum ověření</th></tr></thead><tbody><?php foreach($rows as $r): ?><tr><?php if($r['is_public']): ?><td><span class="avatar"><?=e(mb_substr($r['name'],0,1))?></span><?=e($r['name'])?></td><td><?=e($r['city'])?></td><?php else: ?><td colspan="2" class="anonymous">◉ signatář se rozhodl nezveřejnit své údaje</td><?php endif ?><td><?=e((new DateTimeImmutable($r['verified_at'],new DateTimeZone('UTC')))->setTimezone(new DateTimeZone('Europe/Prague'))->format('d. m. Y'))?></td></tr><?php endforeach ?><?php if(!$rows): ?><tr><td colspan="3" class="empty">Zatím žádné ověřené hlasy. Buďte první, kdo se zapojí.</td></tr><?php endif ?></tbody></table></div><div class="pagination"><span>Strana <?=$page?> z <?=$pages?></span><div><?php if($page>1): ?><a href="?id=<?=$id?>&page=<?=$page-1?>#signatari">← Předchozí</a><?php endif ?><?php if($page<$pages): ?><a href="?id=<?=$id?>&page=<?=$page+1?>#signatari">Další →</a><?php endif ?></div></div></section>
<section class="other"><h2>Další hlasování</h2><?php foreach($all as $a): ?><a href="?id=<?=(int)$a['id']?>"><?=e($a['title'])?> <span><?= $a['mode']==='petition'?'Petice':'Referendum' ?> ↗</span></a><?php endforeach ?></section><details id="soukromi"><summary>Soukromí a zpracování osobních údajů</summary><p><?=e($config['organizer'])?></p><p><?=e($config['privacy'])?></p><p>Uchováváme jméno, obec, e-mail, volbu a čas ověření. E-mail ani individuální volbu nezveřejňujeme. Ověření e-mailu nepotvrzuje totožnost ani volební oprávnění. Toto je občanské hlasování, nikoli úřední referendum nebo automaticky právně platná petice.</p></details></main><footer><a class="brand" href="./">společný hlas.</a><span>Prostor pro váš názor. S respektem k soukromí.</span><a href="#soukromi">Ochrana soukromí ↗</a></footer></body></html>
