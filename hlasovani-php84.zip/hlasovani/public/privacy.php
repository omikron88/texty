<?php
require dirname(__DIR__).'/src/bootstrap.php';
$content=privacyContent();
?><!doctype html><html lang="cs"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Zpracování osobních údajů · Společný hlas</title><link rel="stylesheet" href="style.css"></head><body><header><a class="brand" href="./">společný hlas.</a><nav><a href="./">Zpět na hlasování</a><?=optionalPageLinks()?><a class="privacy-nav" href="privacy.php" aria-current="page">Osobní údaje</a></nav></header><main class="document"><h1>Zpracování osobních údajů</h1><div class="rich-text"><?=privacyHtml($content)?></div></main></body></html>
