<?php
require dirname(__DIR__).'/src/bootstrap.php';
$token=(string)($_GET['token']??$_POST['token']??'');
$valid=preg_match('/^[a-f0-9]{64}$/D',$token)===1;
$v=$valid?query('SELECT v.id,c.title,c.active FROM votes v JOIN campaigns c ON c.id=v.campaign_id WHERE token_hash=? AND verified_at IS NULL AND expires_at>UTC_TIMESTAMP()',[hash('sha256',$token)])->fetch():false;
$done=false;
if($_SERVER['REQUEST_METHOD']==='POST'){
 csrf();
 if($v && $v['active']) {
  $q=query('UPDATE votes v JOIN campaigns c ON c.id=v.campaign_id SET v.verified_at=UTC_TIMESTAMP(),v.token_hash=NULL,v.expires_at=NULL WHERE v.id=? AND v.token_hash=? AND v.verified_at IS NULL AND v.expires_at>UTC_TIMESTAMP() AND c.active=1',[$v['id'],hash('sha256',$token)]);
  $done=$q->rowCount()>0;
 }
}
?><!doctype html><html lang="cs"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Ověření hlasu</title><link rel="stylesheet" href="style.css"></head><body><main class="verify"><a class="brand" href="./">společný hlas.</a><h1><?= $done?'Děkujeme za váš hlas.':($v && $v['active']?'Poslední krok.':'Odkaz již není platný.') ?></h1><?php if($done): ?><p>Váš ověřený hlas byl započítán právě jednou.</p><?php elseif($v && $v['active']): ?><p><?=e($v['title'])?></p><p>Potvrďte odeslaný hlas. Samotné otevření odkazu jej nezapočítá.</p><form method="post" action="verify.php"><input type="hidden" name="token" value="<?=e($token)?>"><input type="hidden" name="csrf" value="<?=e($_SESSION['csrf'])?>"><button>Potvrdit můj hlas ↗</button></form><?php else: ?><p>Odkaz vypršel, byl použit nebo je hlasování uzavřené. Neověřený hlas můžete znovu odeslat z formuláře.</p><?php endif ?><p><a href="./">← Zpět na hlasování</a></p></main></body></html>
