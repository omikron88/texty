"use strict";
document.querySelectorAll('[data-editor]').forEach(box => {
 const source=box.querySelector('textarea');
 const surface=box.querySelector('.editable');
 const preview=box.querySelector('.editor-preview');
 surface.innerHTML=source.value; surface.hidden=false;source.hidden=true;
 box.querySelector('label').hidden=true;
 let selection=null;
 function remember(){const sel=window.getSelection();if(sel.rangeCount && surface.contains(sel.anchorNode))selection=sel.getRangeAt(0).cloneRange();}
 surface.addEventListener('keyup',remember);surface.addEventListener('mouseup',remember);
 surface.addEventListener('input',()=>{source.value=surface.innerHTML;remember();preview.hidden=true;});
 // Paste plain text only. Formatting is added with this editor's controls.
 surface.addEventListener('paste',event=>{event.preventDefault();document.execCommand('insertText',false,event.clipboardData.getData('text/plain'));source.value=surface.innerHTML;});
 surface.addEventListener('drop',event=>event.preventDefault());
 box.querySelectorAll('[data-command]').forEach(button=>{
  button.addEventListener('mousedown',event=>event.preventDefault());
  button.addEventListener('click',()=>{
   surface.focus(); if(selection){const sel=window.getSelection();sel.removeAllRanges();sel.addRange(selection);}
   let value=button.dataset.value||null;
   if(button.dataset.command==='createLink'){
    value=window.prompt('Adresa odkazu (https:// nebo mailto:)','https://');
    if(!value)return;
    if(!/^(https?:\/\/|mailto:)[^\s]+$/i.test(value)){window.alert('Zadejte platnou adresu začínající https://, http:// nebo mailto:.');return;}
   }
   document.execCommand(button.dataset.command,false,value);source.value=surface.innerHTML;remember();preview.hidden=true;
  });
 });
 box.querySelector('[data-preview]').addEventListener('click',()=>{
  preview.replaceChildren(surface.cloneNode(true));
  const copy=preview.firstElementChild;copy.removeAttribute('contenteditable');copy.removeAttribute('role');copy.removeAttribute('aria-label');copy.removeAttribute('aria-multiline');
  preview.hidden=!preview.hidden;
 });
 box.closest('form').addEventListener('submit',()=>{source.value=surface.innerHTML;});
});
