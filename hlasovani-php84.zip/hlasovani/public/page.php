<?php
require dirname(__DIR__).'/src/bootstrap.php';
$slug=is_string($_GET['slug']??null)?$_GET['slug']:'';
$content=privacyContent();
$page=optionalPages($content)[$slug]??null;
if(!$page) {
 http_response_code(404);
 header('X-Robots-Tag: noindex');
}
?><!doctype html><html lang="cs"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=e($page['title']??'Stránka nenalezena')?> · Společný hlas</title><link rel="stylesheet" href="style.css"></head><body><header><a class="brand" href="./">společný hlas.</a><nav><a href="./">Hlasování</a><?=optionalPageLinks($content,$slug)?><a class="privacy-nav" href="privacy.php">Osobní údaje</a></nav></header><main class="document"><h1><?=e($page['title']??'Stránka nenalezena')?></h1><?php if($page): ?><div class="rich-text"><?=$page['html']?></div><?php else: ?><p>Tato stránka nemá zveřejněný obsah.</p><p><a href="./">Zpět na hlasování</a></p><?php endif ?></main></body></html>
