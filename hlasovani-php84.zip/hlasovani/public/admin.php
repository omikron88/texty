<?php
require dirname(__DIR__).'/src/bootstrap.php';
$hash=(string)($config['admin_password_hash']??'');
if($hash==='' || (password_get_info($hash)['algo']??null)===null) {http_response_code(503);exit('Administrace není nastavena. Doplňte admin_password_hash podle README.');}
$binding=hash_hmac('sha256',$hash,$config['secret']);
$auth=isset($_SESSION['admin_at'],$_SESSION['admin_binding']) && time()-(int)$_SESSION['admin_at']<1800 && hash_equals($binding,$_SESSION['admin_binding']);
$error='';$notice='';
if($_SERVER['REQUEST_METHOD']==='POST') {
 csrf();
 if(($_POST['action']??'')==='logout') {
  unset($_SESSION['admin_at'],$_SESSION['admin_binding']);session_regenerate_id(true);header('Location: admin.php',true,303);exit;
 }
 if(!$auth && ($_POST['action']??'')==='login') {
  $bucket=hash_hmac('sha256','admin|'.($_SERVER['REMOTE_ADDR']??'unknown').'|'.gmdate('Y-m-d-H'),$config['secret']);
  query('INSERT INTO rate_limits(bucket,hits,expires_at) VALUES (?,1,DATE_ADD(UTC_TIMESTAMP(),INTERVAL 2 HOUR)) ON DUPLICATE KEY UPDATE hits=hits+1',[$bucket]);
  $hits=(int)query('SELECT hits FROM rate_limits WHERE bucket=?',[$bucket])->fetchColumn();
  if($hits<=10 && password_verify((string)($_POST['password']??''),$hash)) {
   session_regenerate_id(true);$_SESSION['admin_at']=time();$_SESSION['admin_binding']=$binding;$_SESSION['csrf']=bin2hex(random_bytes(32));header('Location: admin.php',true,303);exit;
  }
  $error=$hits>10?'Příliš mnoho pokusů. Zkuste to další hodinu.':'Přihlášení se nezdařilo.';
 } elseif(!$auth) {http_response_code(401);$error='Přihlášení vypršelo. Přihlaste se znovu.';}
}
$id=max(1,(int)($_GET['id']??1));
if($auth) {
 $_SESSION['admin_at']=time();
 // Preserve the original config values when moving privacy content into the database.
 query('INSERT IGNORE INTO site_content(id,organizer,privacy_html) VALUES (1,?,?)',[$config['organizer'],nl2br(e($config['privacy']))]);
 $campaign=query('SELECT * FROM campaigns WHERE id=?',[$id])->fetch();
 if(!$campaign){http_response_code(404);exit('Hlasování neexistuje.');}
 $privacy=privacyContent();
 $campaignStamp=hash('sha256',json_encode([$campaign['title'],$campaign['body'],$campaign['body_html']]));
 $privacyStamp=hash('sha256',json_encode([$privacy['organizer'],$privacy['privacy_html']]));
 if($_SERVER['REQUEST_METHOD']==='POST' && in_array($_POST['action']??'',['campaign','privacy','about','press'],true)) {
  try {
   if(strlen((string)($_POST['body_html']??''))>60000) throw new RuntimeException('Text je příliš dlouhý (maximum 60 kB).');
   $html=cleanHtml((string)($_POST['body_html']??''));
   if(strlen($html)>80000) throw new RuntimeException('Formátovaný text je příliš dlouhý. Zkraťte jej prosím.');
   if(in_array($_POST['action'],['campaign','privacy'],true) && !hasVisibleText($html)) throw new RuntimeException('Text nesmí být prázdný.');
   $db->beginTransaction();
   if($_POST['action']==='campaign') {
    $current=query('SELECT * FROM campaigns WHERE id=? FOR UPDATE',[$id])->fetch();
    $stamp=hash('sha256',json_encode([$current['title'],$current['body'],$current['body_html']]));
    if(!hash_equals($stamp,(string)($_POST['stamp']??''))) throw new RuntimeException('Obsah mezitím někdo změnil. Obnovte stránku a úpravy zopakujte.');
    $title=trim((string)($_POST['title']??''));
    if(mb_strlen($title)<2 || mb_strlen($title)>240) throw new RuntimeException('Název musí mít 2 až 240 znaků.');
    history('campaign',$id,['before'=>['title'=>$current['title'],'body'=>$current['body'],'body_html'=>$current['body_html']],'after'=>['title'=>$title,'body_html'=>$html]]);
    query('UPDATE campaigns SET title=?,body=?,body_html=? WHERE id=?',[$title,html_entity_decode(strip_tags(str_replace(['</p>','</div>','<br>','</li>'],"\n",$html)),ENT_QUOTES,'UTF-8'),$html,$id]);
   } elseif($_POST['action']==='privacy') {
    $current=privacyContent(true);
    $stamp=hash('sha256',json_encode([$current['organizer'],$current['privacy_html']]));
    if(!hash_equals($stamp,(string)($_POST['stamp']??''))) throw new RuntimeException('Poučení mezitím někdo změnil. Obnovte stránku a úpravy zopakujte.');
    $organizer=trim((string)($_POST['organizer']??''));
    if($organizer==='' || mb_strlen($organizer)>2000) throw new RuntimeException('Vyplňte správce údajů (nejvýše 2000 znaků).');
    history('privacy',null,['before'=>['organizer'=>$current['organizer'],'privacy_html'=>$current['privacy_html']],'after'=>['organizer'=>$organizer,'privacy_html'=>$html]]);
    query('UPDATE site_content SET organizer=?,privacy_html=? WHERE id=1',[$organizer,$html]);
   } else {
    $slug=$_POST['action'];
    $definition=optionalPageDefinitions()[$slug];
    $column=$definition['column']; // From the fixed server-side allowlist, never from user input.
    $current=privacyContent(true);
    $stamp=hash('sha256',(string)($current[$column]??''));
    if(!hash_equals($stamp,(string)($_POST['stamp']??''))) throw new RuntimeException('Stránku mezitím někdo změnil. Obnovte stránku a úpravy zopakujte.');
    if(!hasVisibleText($html)) $html='';
    history('page',null,['page'=>$slug,'before'=>(string)($current[$column]??''),'after'=>$html]);
    query('UPDATE site_content SET '.$column.'=? WHERE id=1',[$html]);
   }
   $db->commit();header('Location: admin.php?id='.$id.'&saved=1',true,303);exit;
  } catch(Throwable $ex) {
   if($db->inTransaction()) $db->rollBack();
   $error=$ex instanceof RuntimeException && !($ex instanceof PDOException)?$ex->getMessage():'Uložení se nezdařilo. Zkontrolujte serverový log.';
   if($ex instanceof PDOException) error_log('Admin save failed: '.get_class($ex));
  }
 }
 $all=query('SELECT id,title FROM campaigns ORDER BY id')->fetchAll();
}
function postedEditorHtml(string $action,string $fallback): string {
 if(($_POST['action']??'')!==$action) return $fallback;
 try { return cleanHtml((string)($_POST['body_html']??'')); } catch(RuntimeException $ex) { return $fallback; }
}
function editor(string $key,string $html): void { ?>
<div class="editor" data-editor><div class="toolbar" role="toolbar" aria-label="Formátování textu">
<button type="button" data-command="bold" aria-label="Tučně"><strong>B</strong></button><button type="button" data-command="italic" aria-label="Kurzíva"><em>I</em></button><button type="button" data-command="formatBlock" data-value="h2">Nadpis</button><button type="button" data-command="formatBlock" data-value="p">Odstavec</button><button type="button" data-command="insertUnorderedList">• Seznam</button><button type="button" data-command="insertOrderedList">1. Seznam</button><button type="button" data-command="createLink">Odkaz</button><button type="button" data-command="unlink">Zrušit odkaz</button><button type="button" data-command="removeFormat">Zrušit formát</button></div>
<label for="<?=$key?>-source">Text (bez JavaScriptu lze upravovat HTML v tomto poli)</label><textarea id="<?=$key?>-source" name="body_html" rows="12" maxlength="100000"><?=e($html)?></textarea><div class="editable rich-text" contenteditable="true" role="textbox" aria-label="Vizuální editor textu" aria-multiline="true" hidden></div><button class="preview-button" type="button" data-preview>Náhled</button><div class="editor-preview rich-text" hidden></div></div>
<?php }
?><!doctype html><html lang="cs"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Administrace · Společný hlas</title><link rel="stylesheet" href="style.css"><script src="editor.js" defer></script></head><body><header><a class="brand" href="./">společný hlas.</a><nav><a href="./">Hlasování</a><?=optionalPageLinks()?><a class="privacy-nav" href="privacy.php">Osobní údaje</a></nav></header><main class="admin"><h1>Správa obsahu</h1><?php if($error): ?><p role="alert" class="error"><?=e($error)?></p><?php endif ?><?php if(!$auth): ?><form method="post" class="login"><input type="hidden" name="csrf" value="<?=e($_SESSION['csrf'])?>"><input type="hidden" name="action" value="login"><label class="field">Heslo správce<input type="password" name="password" autocomplete="current-password" required></label><button>Přihlásit se</button></form><?php else: ?>
<?php if(isset($_GET['saved'])): ?><p class="notice" role="status">Změny byly uloženy do databáze.</p><?php endif ?><form method="post" class="logout"><input type="hidden" name="csrf" value="<?=e($_SESSION['csrf'])?>"><button name="action" value="logout">Odhlásit se</button></form><h2>Vyberte výzvu</h2><ul><?php foreach($all as $item): ?><li><a href="admin.php?id=<?=(int)$item['id']?>"><?=e($item['title'])?></a></li><?php endforeach ?></ul>
<p class="notice">U nových hlasů uchováváme znění výzvy i poučení při odeslání. Při zásadní změně otázky založte nové hlasování. Poučení je společné pro všechny výzvy.</p>
<section class="admin-card"><h2>Výzva</h2><form method="post"><input type="hidden" name="csrf" value="<?=e($_SESSION['csrf'])?>"><input type="hidden" name="action" value="campaign"><input type="hidden" name="stamp" value="<?=e($campaignStamp)?>"><label class="field">Název výzvy<input name="title" required maxlength="240" value="<?=e(($_POST['action']??'')==='campaign'?($_POST['title']??$campaign['title']):$campaign['title'])?>"></label><?php editor('campaign',postedEditorHtml('campaign',campaignHtml($campaign))); ?><button>Uložit výzvu</button></form></section>
<section class="admin-card"><h2>Poučení o osobních údajích</h2><form method="post"><input type="hidden" name="csrf" value="<?=e($_SESSION['csrf'])?>"><input type="hidden" name="action" value="privacy"><input type="hidden" name="stamp" value="<?=e($privacyStamp)?>"><label class="field">Správce údajů a kontakt<input name="organizer" required maxlength="2000" value="<?=e(($_POST['action']??'')==='privacy'?($_POST['organizer']??$privacy['organizer']):$privacy['organizer'])?>"></label><?php editor('privacy',postedEditorHtml('privacy',cleanHtml($privacy['privacy_html']))); ?><p class="muted">Pod poučením se také zobrazí základní vysvětlení, jak hlasování funguje.</p><button>Uložit poučení</button></form></section>
<section class="admin-card"><h2>Volitelné stránky</h2><p class="muted">Vyplněná stránka se automaticky objeví v horní liště. Pro skrytí smažte celý obsah a uložte prázdnou stránku. Každá stránka se ukládá samostatně.</p></section>
<?php foreach(optionalPageDefinitions() as $slug=>$definition): $pageHtml=(string)($privacy[$definition['column']]??''); ?>
<section class="admin-card"><h2><?=e($definition['title'])?></h2><form method="post"><input type="hidden" name="csrf" value="<?=e($_SESSION['csrf'])?>"><input type="hidden" name="action" value="<?=e($slug)?>"><input type="hidden" name="stamp" value="<?=e(hash('sha256',$pageHtml))?>"><?php editor($slug,postedEditorHtml($slug,cleanHtml($pageHtml))); ?><button>Uložit stránku <?=e($definition['title'])?></button></form></section>
<?php endforeach ?>
<?php endif ?></main></body></html>
